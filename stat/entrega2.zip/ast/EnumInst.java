package ast;

public enum EnumInst {
	BLOCK, IF, ASIG, REPEAT, CASE, FUN_DEF, TIPO_DEF, FUN_CALL, DEC, RETURN
}
