package ast;

public interface Inst extends NodoAst {
	public EnumInst getInst();
}
