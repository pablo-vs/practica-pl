package ast.tipos;
import ast.NodoAst;

public interface Tipo extends NodoAst {
	public EnumTipo getTipo();
}
