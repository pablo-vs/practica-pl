package ast.tipos;

public enum EnumTipo {
	IDENTIPO, ARRAY, TUPLA, DICT, STRUCT, PUNT, TINT, TDEC, TSTRING, TBOOL
}
